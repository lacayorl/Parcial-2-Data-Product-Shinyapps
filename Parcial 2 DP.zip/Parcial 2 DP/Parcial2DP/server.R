library(shiny)
library(shinyWidgets)
library(dplyr)
library(ggplot2)
library(readr)
library(rworldmap)
library(plotly)
library(rsconnect)
library(readr)
AmazonTitles <- read.csv("amazon_prime_titles.csv")
AmazonTitles <- AmazonTitles %>% select(-c(description, show_id))

Movies <- AmazonTitles %>% 
    filter(type=='Movie')

Series <- AmazonTitles %>% 
    filter(type=='TV Show')
##### -------------- Cleaning -------------------------------- #######

Movies <- Movies %>% 
    mutate(duration= gsub(pattern = " min",
                          replacement = "", 
                          x = duration))
Movies$duration <- as.numeric(Movies$duration)

Series <- Series %>% 
    mutate(Seasons= gsub(pattern = " Seasons?",
                         replacement = "", 
                         x = duration)) %>% 
    mutate(Seasons= gsub(pattern = "s",
                         replacement = "",
                         x = Seasons))
Series$Seasons <- as.numeric(Series$Seasons)

Onlist_Cat <- unlist(strsplit(AmazonTitles$listed_in, ", "))
Categories <-  unique(Onlist_Cat)
Categories <- Categories[-18]
### -------------------------------------------------- ##### 

Codes <- read_csv("countries_codes_and_coordinates.csv")
Codes <- Codes %>% select(Country, `Alpha-3 code`)

Paises <- strsplit(x = AmazonTitles$country, split = ", ")
Paises <- unlist(Paises)
Paises <- data.frame(table(Paises))
Paises <- Paises %>% rename(Country = Paises)
Paises <- left_join(x = Paises, y = Codes)
Paises <- Paises %>% rename(Code = `Alpha-3 code`)


# ----------------------------------------------------- ##

shinyServer(function(input, output, session) {
    
    output$tabla1 <- DT::renderDataTable({
        AmazonTitles %>% DT::datatable(selection = 'multiple',
                                       rownames = FALSE,
                                       filter = 'top',
                                       extensions = 'Buttons',
                                       options = list(
                                           pageLength = 10,
                                           lengthMenu = c(5,10,15),
                                           dom = 'Bfrtip',
                                           buttoms = c('csv')
                                           ))
    })
    
    output$output_tabla1 <- renderPrint({
        input$tabla1_rows_selected
    })
    
    observeEvent(input$tipo,{
        updateTabsetPanel(session,'params',selected = input$tipo)
    })
    
    
    observeEvent(input$mostrar, {     
        output$tabla2 <- DT::renderDataTable({
            if (input$tipo=='Movie'){
                Movies <- Movies %>% 
                    filter(duration <= input$dur)
                Movies <- Movies[grepl(input$genero, Movies$listed_in), ]
                Movies
            } else {
                Series <- Series %>% 
                    filter(Seasons == input$season)
                Series <- Series[grepl(input$genero, Series$listed_in), ]
                Series
            }
        })
        
    }) 
    
    
    output$grafica_mapa <- renderPlot({
        visitedMap <- joinCountryData2Map(Paises, 
                                          joinCode = "ISO3",
                                          nameJoinColumn = "Code")
        
         mapCountryData(visitedMap, 
                        nameColumnToPlot="Freq",
                        oceanCol = "azure2",
                        catMethod = "categorical",
                        missingCountryCol = gray(.8),
                        colourPalette = c("coral",
                                          "coral2",
                                          "coral3", "orangered", 
                                          "orangered3", "orangered4"),
                        addLegend = T,
                        mapTitle = "Número de titulos por país de filmacion",
                        border = NA)
    })
    
    output$grafica_rating <- renderPlotly({
        data_tabla <- AmazonTitles %>% 
            group_by(rating, year=release_year) %>% 
            summarise(Cantidad = n())
        g1 <- ggplot(data_tabla,aes(x = year,y = Cantidad, fill = rating))+
                geom_bar(stat = 'identity')
        ggplotly(g1)
    })
    
    output$grafica_tipo <- renderPlotly({
        data_tabla2 <- AmazonTitles %>% 
            group_by(type, year=release_year) %>% 
            summarise(Cantidad = n())
        g2 <- ggplot(data_tabla2, aes(x = year, y = Cantidad, colour = type))+
            geom_line(lwd=2)
        ggplotly(g2)
    })
    
    observeEvent(input$tipo2,{
        updateTabsetPanel(session,'params',selected = input$tipo2)
    })
    
    
    observe({     
        output$tabla3 <- DT::renderDataTable({
            if (input$tipo2=='Movie'){
                Movies <- Movies[grepl(input$genero2, Movies$listed_in), ]
                Movies
            } else {
                Series <- Series[grepl(input$genero2, Series$listed_in), ]
                Series
            }
        })
        
    })
    
    observe({
        query <- parseQueryString(session$clientData$url_search)
        tipo <- query[['tipo2']]
        genero <- query[['genero2']]
        if(!is.null(tipo)){
            updateSelectInput(session,'tipo2',selected = tipo)
        }
        if(!is.null(genero)){
            updateSelectInput(session,'genero2',selected = genero)
        }
    })
    
    observe({
        tipo <- input$tipo2
        genero <- input$genero2
        if(session$clientData$url_port==''){
            url1 <- NULL
        }else{
            url1 <- paste0(':',
                           session$clientData$url_port)
        }
        cod <- paste0('http://',
                      session$clientData$url_hostname,
                      url1,
                      session$clientData$url_pathname,
                      '?',
                      'tipo=',
                      tipo,
                      '&',
                      'genero=',
                      genero)
        updateTextInput(session,'url',value = cod)
    })
    
    observe({
        data <- parseQueryString(session$clientData$url_search)
        session$sendCustomMessage(type='updateSelections',data)
        updateSelectInput(session,'beverage',selected = data$beverage)
    })
    
})
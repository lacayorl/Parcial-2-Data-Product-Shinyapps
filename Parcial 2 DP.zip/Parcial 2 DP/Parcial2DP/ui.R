library(shiny)
library(dplyr)
library(shinyWidgets)
library(plotly)
library(rsconnect)
library(readr)
AmazonTitles <- read.csv("amazon_prime_titles.csv")
AmazonTitles <- AmazonTitles %>% select(-c(description, show_id))

Movies <- AmazonTitles %>% 
    filter(type=='Movie')

Series <- AmazonTitles %>% 
    filter(type=='TV Show')
##### -------------- Cleaning -------------------------------- #######

Movies <- Movies %>% 
    mutate(duration= gsub(pattern = " min",
                          replacement = "", 
                          x = duration))
Movies$duration <- as.numeric(Movies$duration)

Series <- Series %>% 
    mutate(Seasons= gsub(pattern = " Seasons?",
                         replacement = "", 
                         x = duration)) %>% 
    mutate(Seasons= gsub(pattern = "s",
                         replacement = "",
                         x = Seasons))
Series$Seasons <- as.numeric(Series$Seasons)

Onlist_Cat <- unlist(strsplit(AmazonTitles$listed_in, ", "))
Categories <-  unique(Onlist_Cat)
Categories <- Categories[-18]
### -------------------------------------------------- ##### 

Codes <- read_csv("countries_codes_and_coordinates.csv")
Codes <- Codes %>% select(Country, `Alpha-3 code`)

Paises <- strsplit(x = AmazonTitles$country, split = ", ")
Paises <- unlist(Paises)
Paises <- data.frame(table(Paises))
Paises <- Paises %>% rename(Country = Paises)
Paises <- left_join(x = Paises, y = Codes)
Paises <- Paises %>% rename(Code = `Alpha-3 code`)


# ----------------------------------------------------- ##
shinyUI(fluidPage(
    
    setBackgroundColor(
        color = c("#F7FBFF", "#2171B5"),
        gradient = "linear",
        direction = "bottom"
    ),
    
    titlePanel("Amazon Prime Video Web App"),
    tabsetPanel(
        tabPanel('Buscador',
                 h1('¿No sabes que ver?'),
                 selectInput('genero','Genero',
                             choices = Categories
                             ),
                 selectInput('tipo', 'Tipo',
                             choices = AmazonTitles$type
                             ),
                 tabsetPanel(
                     id='params',
                     type='hidden',
                     tabPanel('Movie',
                              sliderInput('dur', 'Duración en minutos',
                                          value = mean(Movies$duration), 
                                          min = min(Movies$duration),
                                          max = max(Movies$duration)
                                          )
                              ),
                     tabPanel('TV Show',
                              selectInput('season', 'Season',
                                          choices = sort(Series$Seasons)
                                          ))
                              ),
                 
                 actionButton(inputId = 'mostrar', label = "Ver Resultados", 
                              icon = icon("refresh"), 
                              style="color: #fff; background-color: #e95420; border-color: #c34113;
                                 border-radius: 10px; 
                                 border-width: 2px"),
                 hr(),
                 DT::dataTableOutput('tabla2'),
                 verbatimTextOutput('output_tabla2')
                 
                 ),
        tabPanel('Info del contenido en Prime Video',
                 h1('Geo informacion'),
                 plotOutput('grafica_mapa'),
                 h1('Cantidad de titulos por año de filmación y rating'),
                 plotlyOutput('grafica_rating'),
                 h1('Cantidad de títulos por año de filmación y tipo'),
                 plotlyOutput('grafica_tipo')
                
                ),
        tabPanel('Descargar dataset',
                 h1('Títulos en Amazon'),
                 fluidRow(column(12,
                                 DT::dataTableOutput('tabla1'),
                                 verbatimTextOutput('output_tabla1')
                                )
                         )
                ),
        
        tabPanel('Filtro con URL',
                 h1('Contenido de Amazon Prime'),
                 sidebarLayout(
                     sidebarPanel(selectInput('tipo2','Tipo',
                                              choices = AmazonTitles$type,
                                              selected = 'Movie'),
                                  selectInput('genero2','Genero',
                                              choices = Categories,
                                              selected = 'Comedy'),
                                  textInput('url','Copy URL', value = '')
                                  ),
                     mainPanel(
                         DT::dataTableOutput('tabla3'),
                         verbatimTextOutput('output_tabla3')
                     )
                 ),
                 )
        
    )
    
))
